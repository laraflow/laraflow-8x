# HTTP Status Code Images 1.0

This work is licensed under the [Creative Commons Attribution 4.0 International License](http://creativecommons.org/licenses/by/4.0/).

This means you may use it for any purpose, and make any changes you like. All we ask is that you include a link back to the original blog post at https://www.drlinkcheck.com/blog/free-http-error-images.